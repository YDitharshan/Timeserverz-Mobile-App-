package com.project.find_worker_project;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class detailsDB extends SQLiteOpenHelper {
    public static final String database_Name = "details.db";
    public detailsDB(@Nullable Context context) {
        super(context , "details.db",null,1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table details(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT , problem TEXT, number STRING)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("drop table if exists details");
        onCreate(db);
    }

    public Boolean insertDetails(String name, String problem, String number){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("name",name);
        contentValues.put("problem",problem);
        contentValues.put("number",number);
        long result = db.insert("details",null, contentValues);
        if(result == -1){
            return false;
        }else{
            return true;
        }
    }
}
